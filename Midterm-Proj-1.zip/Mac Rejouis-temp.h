//Mac Rejouis
#include <iostream>
using namespace std;

int main()
{
  int arr[] = {50, 85, 63, 75, 87, 93, 84, 80, 90, 30, 41, 94, 13, 42};   //Step 0: Test the array of size 14
  const int SIZE = 14;                                                    //Step 1: Ask a question: is this integer greater than 70?
  int temp = 0;                                                             
  
  for (int i=0; i<SIZE; i++)                                              //Step 2: Make a for loop
  {
    if (arr[i] > 70)                                                      //Step 3: Find an integer that is greater than 70
    {
      cout << arr[i] << " ";
    }  
  }
}